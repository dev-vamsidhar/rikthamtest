class Usermodel {
  String name = "";
  String email = "";
  String username = "";
}
