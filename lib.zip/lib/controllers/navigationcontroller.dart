import 'package:get/state_manager.dart';

class NavigationController extends GetxController {
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }

  RxInt index = 0.obs;
}
